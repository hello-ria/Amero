double? h;
double? w;

//Images
const String logo = 'assets/images/logo.png';
const String illustration1 = 'assets/images/illustration1.png';
const String illustration2 = 'assets/images/illustration2.png';
const String illustration3 = 'assets/images/illustration3.png';
const String google = 'assets/images/google.png';
const String fb = 'assets/images/fb.png';
const String cocacola = 'assets/images/cocacola.png';
const String samsung = 'assets/images/samsung.png';
const String dashboard = 'assets/images/dashboard.png';
const String vector1 = 'assets/images/vector.png';
const String vector2 = 'assets/images/vector1.png';
