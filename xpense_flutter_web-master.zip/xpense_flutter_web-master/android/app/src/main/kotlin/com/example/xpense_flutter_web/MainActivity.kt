package com.example.xpense_flutter_web

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
