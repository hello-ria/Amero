import 'package:flutter/material.dart';

class AppColors {
  static Color primary = Colors.deepOrange;
}
